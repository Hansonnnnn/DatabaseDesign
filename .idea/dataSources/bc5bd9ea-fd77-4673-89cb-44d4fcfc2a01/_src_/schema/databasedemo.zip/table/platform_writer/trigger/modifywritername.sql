CREATE TRIGGER modifywritername
BEFORE INSERT ON platform_writer
FOR EACH ROW
  BEGIN SET NEW.writer_name = concat('w_', NEW.writer_name); END;
