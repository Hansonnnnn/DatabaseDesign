CREATE TRIGGER updateUser
BEFORE UPDATE ON user_info
FOR EACH ROW
  BEGIN
    SET NEW.balance = NEW.balance - 3;
  END;
