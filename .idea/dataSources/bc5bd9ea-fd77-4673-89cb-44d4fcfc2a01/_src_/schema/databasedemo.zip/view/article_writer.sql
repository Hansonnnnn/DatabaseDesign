CREATE VIEW article_writer AS
  SELECT
    `pa`.`article_id`        AS `article_id`,
    `pa`.`writer_id`         AS `writer_id`,
    `pa`.`article_title`     AS `article_title`,
    `pa`.`content`           AS `content`,
    `pa`.`create_time`       AS `create_time`,
    sum(`pd`.`deal_payment`) AS `total_payment`,
    `pw`.`writer_name`       AS `writer_name`,
    `pw`.`writer_email`      AS `writer_email`
  FROM `databasedemo`.`platform_writer` `pw`
    JOIN `databasedemo`.`platform_article` `pa`
    JOIN `databasedemo`.`platform_deal` `pd`
  WHERE ((`pw`.`writer_id` = `pa`.`writer_id`) AND (`pd`.`article_id` = `pa`.`article_id`))
  GROUP BY `pa`.`article_id`;
